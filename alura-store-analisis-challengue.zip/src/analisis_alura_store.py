#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "outputs"
OUT_G = OUT / "graficos"
OUT.mkdir(parents=True, exist_ok=True)
OUT_G.mkdir(parents=True, exist_ok=True)

def infer_store_from_filename(path: Path) -> str:
    return path.stem.replace("_", " ").title()

def load_all_csv(data_dir: Path) -> pd.DataFrame:
    files = sorted(data_dir.glob("*.csv"))
    if not files:
        raise FileNotFoundError("No se encontraron CSV en data/.")
    frames = []
    for f in files:
        df = pd.read_csv(f)
        if "store" not in df.columns:
            df["store"] = infer_store_from_filename(f)
        frames.append(df)
    return pd.concat(frames, ignore_index=True)

def compute_line_revenue(df: pd.DataFrame) -> pd.DataFrame:
    if "line_revenue" in df.columns: return df
    if {"quantity","unit_price"}.issubset(df.columns):
        df["line_revenue"] = df["quantity"] * df["unit_price"]
    elif "revenue" in df.columns:
        df["line_revenue"] = df["revenue"]
    else:
        df["line_revenue"] = 0.0
        print("[AVISO] No hay columnas suficientes para calcular ingresos; se usará 0.")
    return df

def minmax(s):
    if s.max() == s.min(): return pd.Series(1.0, index=s.index)
    return (s - s.min()) / (s.max() - s.min())

def main():
    df = load_all_csv(DATA)
    df = compute_line_revenue(df)

    # Resumen por tienda
    summary = (df.groupby("store")["line_revenue"].sum().rename("revenue_total").to_frame())

    if "order_id" in df.columns:
        summary = summary.join(df.groupby("store")["order_id"].nunique().rename("unique_orders"))
        summary["rev_per_order"] = (summary["revenue_total"]/summary["unique_orders"]).round(2)
    if "review_score" in df.columns:
        summary = summary.join(df.groupby("store")["review_score"].mean().rename("review_promedio").round(2))
    if "shipping_days" in df.columns:
        summary = summary.join(df.groupby("store")["shipping_days"].mean().rename("envio_promedio_dias").round(2))

    summary = summary.reset_index().sort_values("revenue_total", ascending=False)
    summary.to_csv(OUT / "resumen_por_tienda.csv", index=False)

    # Gráficos
    plt.figure(); plt.bar(summary["store"], summary["revenue_total"])
    plt.title("Ingresos por tienda"); plt.xticks(rotation=15); plt.tight_layout()
    plt.savefig(OUT_G / "ingresos_por_tienda.png", dpi=160); plt.close()

    if "review_promedio" in summary.columns:
        plt.figure(); plt.bar(summary["store"], summary["review_promedio"])
        plt.title("Review promedio por tienda"); plt.ylim(0,5); plt.xticks(rotation=15); plt.tight_layout()
        plt.savefig(OUT_G / "reviews_por_tienda.png", dpi=160); plt.close()

    if "envio_promedio_dias" in summary.columns:
        plt.figure(); plt.bar(summary["store"], summary["envio_promedio_dias"])
        plt.title("Días de envío promedio"); plt.xticks(rotation=15); plt.tight_layout()
        plt.savefig(OUT_G / "envio_promedio_por_tienda.png", dpi=160); plt.close()

    # Ranking
    rank = summary.copy()
    rank["costo_ingreso"] = 1 - minmax(rank["revenue_total"])
    rank["costo_review"] = 1 - minmax(rank["review_promedio"]) if "review_promedio" in rank.columns else 0.5
    rank["costo_envio"] = minmax(rank["envio_promedio_dias"]) if "envio_promedio_dias" in rank.columns else 0.5
    w_ing, w_rev, w_ship = 0.45, 0.35, 0.20
    rank["score_ineficiencia"] = w_ing*rank["costo_ingreso"] + w_rev*rank["costo_review"] + w_ship*rank["costo_envio"]
    rank = rank.sort_values("score_ineficiencia", ascending=False).reset_index(drop=True)
    rank.to_csv(OUT / "ranking_ineficiencia.csv", index=False)

    worst = rank.iloc[0]; best = rank.iloc[-1]
    reco = f"""Recomendación basada en datos:
- Candidata a vender: {worst['store']}
- Ingresos totales: {worst['revenue_total']:.0f} (mejor: {best['store']} con {best['revenue_total']:.0f})
Sugerencia: evaluar mejoras logísticas/experiencia antes de la venta si el costo-beneficio es favorable.
"""
    (OUT / "recomendacion_alura_store.txt").write_text(reco, encoding="utf-8")

if __name__ == "__main__":
    main()
