# 🏪 Alura Store – Análisis comparativo de 4 tiendas

Estructura lista para ejecutar Pandas + Matplotlib y generar una **recomendación automática**.

## Estructura
```
alura-store-analisis-challengue/
├─ data/                 # CSV por tienda
├─ src/                  # script ejecutable del análisis
├─ notebooks/            # notebook paso a paso
└─ outputs/              # resultados y gráficos
```
Archivos copiados en `data/`:
- tienda_1.csv
- tienda_2.csv
- tienda_3.csv
- tienda_4.csv

## Ejecutar
```bash
pip install -r requirements.txt
python src/analisis_alura_store.py
```
